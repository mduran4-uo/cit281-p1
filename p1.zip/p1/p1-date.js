/*

    CIT 281 Project 1
    Name: Margarita Duran 

*/

function getWeekDay(date){

    let weekdays = new Array(
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    );
   
    let day = date.getDay();
    
    return weekdays[day];
}
let date = new Date();
let weekDay = getWeekDay(date);
console.log(weekDay);