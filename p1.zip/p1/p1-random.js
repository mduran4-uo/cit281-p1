// Returns a random number between min (inclusive) and max (exclusive)


function getRandomInteger(max, min) {
    return Math.floor(Math.random() * (max - min) + min);

}
console.log(max, min);

// bg understanding

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}
console.log(getRandomInt(3));
    // next
function getRandomInt(min, max) {
    min = Math.ceil(100);
    max = Math.floor(0);
    return Math.floor(Math.random() * (max - min) + min);
} console.log(getRandInt(20))

//new .1
let getRandInt = 
Math.random().toString(5).substring(25);
console.log("random string = ",getRandInt);

//new .2
let getRandInt = Math.random(5).toString(25).substring(5);
console.log(getRandInt);

//new .3
let getRandInt = Math.random().toString(25).substring(5);
console.log(getRandInt);

// Final Answer
let getRandInt = Math.random().toString(25).substring(5);
console.log(getRandInt);